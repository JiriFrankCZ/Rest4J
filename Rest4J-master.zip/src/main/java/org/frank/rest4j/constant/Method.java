package org.frank.rest4j.constant;

/**
 * Created by FrankJ on 22.7.2015.
 */
public enum Method {
    POST,	// Create
    GET,	// Read
    PUT,	// Update
    DELETE  // Delete
}
