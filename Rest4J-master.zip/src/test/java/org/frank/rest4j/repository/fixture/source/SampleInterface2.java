package org.frank.rest4j.repository.fixture.source;

/**
 * Created by Ji�� on 1. 7. 2015.
 */
public interface SampleInterface2 {
}
