package org.frank.rest4j.repository.fixture.domain;

/**
 * Created by FrankJ on 22.7.2015.
 */


public class Client {
    private int id;

    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
