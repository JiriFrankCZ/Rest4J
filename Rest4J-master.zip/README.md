# Rest4J
REST API Client based on interface and annotations generator
